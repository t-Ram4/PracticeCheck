package com.cognizant.truyum.truyumspring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.truyum.truyumspring.model.MenuItem;
import com.cognizant.truyum.truyumspring.service.MenuItemService;

@Controller
public class TruyumController {

	@Autowired
	private MenuItemService menuItemService;
	
	//ApplicationContext context = SpringApplication.run(TruyumController.class);
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String adminMenu(@ModelAttribute("menuItem") MenuItem menuItem, HttpServletRequest request) {
		List<MenuItem> adminMenuList = menuItemService.getMenuItemListAdmin();
		request.setAttribute("adminMenuList", adminMenuList);
		return "menuitemlistadmin";
	}
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String customerMenu(@ModelAttribute("menuItem") MenuItem menuItem, HttpServletRequest request) {
		List<MenuItem> customerMenuList = menuItemService.getMenuItemListCustomer();
		request.setAttribute("customerMenuList", customerMenuList);
		return "menu-item-list-customer";
	}
	
	@RequestMapping(value = "/editmenu", method = RequestMethod.GET)
	public String editMenu(@ModelAttribute("menuItem") MenuItem menuItem, HttpServletRequest request) {
		Integer menuItemId = 4;
		MenuItem menuItemObj = menuItemService.getMenuItem(menuItemId);
		request.setAttribute("menuItem", menuItemObj);
		return "edit-menu-item";
	}
	
	@RequestMapping(value = "modifymenu", method = RequestMethod.GET)
	public String modifyMenu(@ModelAttribute("menuItem") MenuItem menuItem, HttpServletRequest request) {
		menuItemService.modifyMenuItem(menuItem);
		return "edit-menu-item-status";
	}
}
