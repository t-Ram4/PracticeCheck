function validation() {

				var origin = document.forms["menuItemForm"];
                var ne = origin.elements["fdname"];
                var nv = ne.value;
                var nameLength= nv.length;
                var flag = true;
                var flag1 = 0;
				var flag2 = 0;
				 

				if (nv == "") {
					alert("Title is required");
					flag = false;
					flag2=1;
					
				
				}

				if(flag2==0)
                if((nameLength<= 2)||(nameLength>=100)){
                alert("Title should have 2 to 65 characters");
                flag = false;
				
				}
                
                var pe = origin.elements["fprice"];
                var pv = pe.value;
                var pl = pv.length;
                
                if(pl==0){
                                alert("Price is required");
                                return false;
                                flag = false;

}
                var i;
                
                for(i=0;i<pl;i++){
                
                 
                            if(!(((pv.charAt(i)>=0)&&(pv.charAt(i)<=9))||(pv.charAt(i)=='.'))){
                                            alert("Price has to be a number");
                                            return false;
                                            flag = false;

                            }

				}

				var de = origin.elements["fdate"];
                var dv = de.value;
                if(dv=="") {
                alert("Date of Launch is required");
                flag = false;

                }
				 var cat =origin.elements["fcate"].value;

				 if(cat == ""){
				 	alert("select anyone category.");
					flag = false;
				 }

		return flag;	
}


