package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.com.util.DateUtil;

public  class MenuItemDaoCollectionImpl implements MenuItemDao  {
	
	static List<MenuItem> menuItemList;     //menuitemlist belongs to admin//
	
	
	public MenuItemDaoCollectionImpl() throws ParseException{
		
		if (menuItemList == null) {
			
			menuItemList = new ArrayList<MenuItem>();
			
			MenuItem sandwich = new MenuItem(1L,"sandwich",99.54f,true,DateUtil.convertToDate("15/03/2017"),"Main Course",true);
			MenuItem Burger = new MenuItem(2L,"Burger",129.98f,true,DateUtil.convertToDate("23/12/2017"),"Main Course",false);
			MenuItem Pizza = new MenuItem(3L,"Pizza",149.45f,true,DateUtil.convertToDate("21/08/2017"),"Main Course",false);
			MenuItem FrenchFries = new MenuItem(4L,"French Fries",57.75f,false,DateUtil.convertToDate("02/07/2017"),"Starters",true);
			MenuItem ChocolateBrownie = new MenuItem(5L,"Chocolate Brownie",32.99f,true,DateUtil.convertToDate("02/11/2022"),"Dessert",true);
			
		       menuItemList.add(sandwich); menuItemList.add(Burger); menuItemList.add(Pizza); menuItemList.add(FrenchFries); menuItemList.add(ChocolateBrownie);
		}
		
		
	}

	
	public List<MenuItem> getMenuItemListAdmin() {
		// TODO Auto-generated method stub
		return menuItemList;
	}

	
	static List<MenuItem> CustomerList;
	
	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
	
		CustomerList = new ArrayList<MenuItem>();
		
		for(MenuItem item:menuItemList) {
			
			Date d = new Date();
			
			String dt = new SimpleDateFormat("dd/MM/yyyy").format(d);
			
			Date tdate = null;
			
			try {
				
				tdate = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
				
			} catch (ParseException e1) {
				
				e1.printStackTrace();
			}
			
			if (!(item.getDateOfLaunch().compareTo(tdate)>0)&& item.isActive() ) {
				
				CustomerList.add(item);
				
			}
			
		}
		return CustomerList;
		
	}

	

public void modifyMenuItem(MenuItem menuItem) {
        
        
        for(MenuItem Item1 : menuItemList) {
            
            if(Item1.equals(menuItem)) {
                
            Item1.setPrice(menuItem.getPrice());
            Item1.setName(menuItem.getName());
            Item1.setCategory(menuItem.getCategory());
            Item1.setFreeDelivery(menuItem.isFreeDelivery());
            Item1.setDateOfLaunch(menuItem.getDateOfLaunch());
            Item1.setActive(menuItem.isActive());
            Item1.setId(menuItem.getId());
            
        }
        
      }
        
 }


	

	public MenuItem getMenuItem(long MenuItemId) {
		
		MenuItem Item = null;
		
		//Long mnuItem2 = MenuItemId;
		
		for(MenuItem Item2 : menuItemList) {
			
			if((MenuItemId == (Item2.getId()))) {
				
				 Item =Item2;
				
			}
		}
		return Item;
	}



}