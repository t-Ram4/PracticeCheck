package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {
	
	public CartEmptyException(){
		
		
	
	}
	
	@Override
	public String getMessage(){
		
		return "Cart is Empty.";
	}


}
