package com.cognizant.truyum.dao;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionHandler {
	
	public static Connection getConnection() {
		
		Connection connection = null;
		
		try {
			
			InputStream input = new FileInputStream("C:\\config\\connection.properties");

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
        
                        
            String driver = prop.getProperty("driver");
            
            String url = prop.getProperty("connection-url");
            
            String userId = prop.getProperty("user");
            
            String password= prop.getProperty("password");
            
            
            Class.forName(driver);
            
                  
            connection = DriverManager.getConnection(url, userId, password);
            
            
            

        } catch (Exception ex) {
            ex.printStackTrace();
        }

		return connection;
		
		
	}
	
	
	public static void main(String arg[]) {
		
		getConnection();
		
	}

}
