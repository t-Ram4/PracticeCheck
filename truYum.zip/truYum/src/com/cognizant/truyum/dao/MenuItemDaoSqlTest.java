package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;

import com.cognizant.com.util.DateUtil;
import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoSqlTest {

	public static void main(String[] args) throws ParseException {
		
		getMenuItemAdmin();
		getMenuItemCustomer();
		modifyMenuItem();
		getMenuItemAdmin();
		getMenuItem();
		
	}

	static void getMenuItemAdmin() {
		
		MenuItemDaoSqlImpl menuitemdao = new MenuItemDaoSqlImpl();
		
		ArrayList<MenuItem> listAdmin =  (ArrayList<MenuItem>) menuitemdao.getMenuItemListAdmin();
		
		Iterator<MenuItem> itr = listAdmin.iterator();
		
	while(itr.hasNext()) {
		
		MenuItem menuItem = (MenuItem) itr.next();
		
		System.out.println(menuItem.toString());
		
	}

		
	}
	
static void getMenuItemCustomer() {
		
		MenuItemDaoSqlImpl menuitemdao = new MenuItemDaoSqlImpl();
		
		ArrayList<MenuItem> listCustomer =  (ArrayList<MenuItem>) menuitemdao.getMenuItemListCustomer();
		
		Iterator<MenuItem> itr = listCustomer.iterator();
		
	while(itr.hasNext()) {
		
		MenuItem menuItem = (MenuItem) itr.next();
		
		System.out.println(menuItem.toString());
		
	}	
	}
	
static void modifyMenuItem() throws ParseException {
	
	MenuItemDaoSqlImpl menuitemdao = new MenuItemDaoSqlImpl();
	
	MenuItem menuitem =	new MenuItem((long) 2,"dosa",49.00f,true, DateUtil.convertToDate("02/08/2017"),"Tamil Food",true);
	menuitemdao.modifyMenuItem(menuitem);
	
	
	
}

static void getMenuItem() {
	
	System.out.println("inside get menuItem");
	
	MenuItemDaoSqlImpl menuitemdao = new MenuItemDaoSqlImpl();
	
	System.out.println(menuitemdao.getMenuItem(2).toString());
	
}
}
