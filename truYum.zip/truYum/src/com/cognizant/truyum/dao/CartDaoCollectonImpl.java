package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectonImpl implements CartDao {
	
	private static HashMap <Long,Cart> userCarts;
	
	public CartDaoCollectonImpl(){
		
		if(userCarts == null) {
			
			userCarts = new HashMap <Long,Cart>();
			
		}
		
	}
	
	public void addCartItem(long userId, long menuItemId)  {
		
		
		
		MenuItemDao menuItemDao = null;
		try {
			menuItemDao = new MenuItemDaoCollectionImpl();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		
		if(!(userCarts.size() == 0)) {
	
		
		for(Map.Entry<Long,Cart> entry : userCarts.entrySet()) {
			
			// comparing userid for whether its already existing in HashMap.....
			
			List <MenuItem> list = entry.getValue().getMenuItemList();
			
			Iterator<MenuItem> itr = list.iterator();
			
			boolean flag = true;
			
			if(entry.getKey().equals(userId)) {
								
					while(itr.hasNext()) {
						
					if(itr.next().hashCode() == menuItem.hashCode())
					
						flag = false;
					}
			}
			
			if(flag)
			entry.getValue().getMenuItemList().add(menuItem);
		}
		
		}
		
		else{
			
			Cart cart = new Cart();
			
			List<MenuItem> clist = new ArrayList<MenuItem>();
			
			clist.add(menuItem);
			
			cart.setMenuItemList(clist);
			
			userCarts.put(userId, cart);
			
		}
		
		
	}

	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException{
		ArrayList <MenuItem> list=null;
		
		 
		
		if(userCarts.get(userId)==null) {
			
			throw new CartEmptyException();
		}
		
		if(userCarts.get(userId)!=null) {
		
		 list = (ArrayList<MenuItem>) userCarts.get(userId).getMenuItemList();
		
			if(list.isEmpty())
				throw new CartEmptyException();
		
			else {
				
				float tt = 0.0f;
				
				for(MenuItem m : list) {
					
					tt += m.getPrice();
					
				}
				
				userCarts.get(userId).setTotal(tt);
					
			}
		}
			return list;
	}
	
	
	public void removeCartItem( long userId, long  menuItemId) {
		
	List <MenuItem> menuItemList = userCarts.get(userId).getMenuItemList();
	
	Iterator<MenuItem> iterator =  menuItemList.iterator();
	
		while(iterator.hasNext() ) {
			
			if(iterator.next().getId().equals(menuItemId))
				iterator.remove();
				
		}
		
	}
	
	public Cart getCart(long userId){
		 
		Cart cart = null; 
		
		if(userCarts.get(userId)!=null) { 
			   cart = userCarts.get(userId);
		}
		return cart;
	}

}
