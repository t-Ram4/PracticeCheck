package com.cognizant.truyum.dao;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {

	public static void main(String[] args) throws CartEmptyException {
		
		testAddCartItem();
		
		testgetAllCartItem();
		
		testRemoveCartItem();
		
		
	}
	
	static void testAddCartItem() {
		
		CartDao cartDao = new CartDaoCollectonImpl();
		
		cartDao.addCartItem(1,4L);
		
		try {
			System.out.println(cartDao.getAllCartItems(1).toString());
		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	static void testgetAllCartItem() throws CartEmptyException {
		
		CartDao cartDao = new CartDaoCollectonImpl();
		
		try {
			if(cartDao.getAllCartItems(1) == null) {
				throw new CartEmptyException();
			}
			
			else System.out.println(cartDao.getAllCartItems(1).toString());
		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			 System.out.println(e.getMessage());
			
			
		}
		
	}
	
	static void testRemoveCartItem() {
		
		CartDao cartDao = new CartDaoCollectonImpl();
		try {
		cartDao.removeCartItem(1,4L);
		
		System.out.println("Removed Successfully..");
		}
		
		catch(Exception e){
			
			System.out.println("There is no menu item in the Cart.");
			
		}
	}

}
