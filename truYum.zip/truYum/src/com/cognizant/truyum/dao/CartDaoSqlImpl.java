package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImpl implements CartDao {
	
	
	
	@Override
	public void addCartItem(long userId, long menuItemId) {
		
		Connection con = ConnectionHandler.getConnection();
		
		try {
			
			String sql = "insert into truyum.cart (ct_us_id,ct_me_id) values(?,?)";
			
			PreparedStatement stmt=con.prepareStatement(sql);
			
			stmt.setInt(1, (int) userId);
			stmt.setInt(2, (int) menuItemId);
			
			stmt.executeUpdate();
			
	
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
		
		Connection con = ConnectionHandler.getConnection();
		
		ArrayList<MenuItem> menuItemList = new ArrayList<MenuItem>();
		
		Cart cart = new Cart();
		
		try {
			
			String sql = "select * from truyum.menu_item mi "
					+ " join cart ct on mi.me_id = ct.ct_me_id "
					+ "  where ct_us_id =?";
			
			String sqltotal = "select sum(me_price) from menu_item mi  inner join cart ct   where ct.ct_me_id = mi.me_id and ct.ct_us_id =? ";
			
			PreparedStatement stmttotal=con.prepareStatement(sqltotal);
			
			stmttotal.setInt(1, (int)userId);
			
			ResultSet rstotal = stmttotal.executeQuery();
			
			while (rstotal.next()) {
				
				 cart.setTotal(rstotal.getFloat(1));
				
			}
			
			PreparedStatement stmt=con.prepareStatement(sql);
			
			stmt.setInt(1, (int) userId);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				long id = (long) rs.getInt(1);
				
				String name = rs.getString(2);
				
				float price = rs.getFloat(3);
				
				String activ = rs.getString(4);
				
				boolean active = activ.equalsIgnoreCase("yes")? true :false;
				
				Date dat= rs.getDate(5);
				
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				
				String modDate = format.format(dat);
				
				Date fdate=null;
				try {
					fdate = format.parse(modDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String category = rs.getString(6);
				
				Boolean delivery = rs.getString(7).equalsIgnoreCase("yes") ? true : false;
				
				MenuItem mi = new MenuItem(id,name,price,active,fdate,category,delivery);
				
				menuItemList.add(mi);
				
			}
			
			cart.setMenuItemList(menuItemList);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return cart.getMenuItemList();
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		
		Connection con = ConnectionHandler.getConnection();
		
		try {
			
			String sql = "delete from truyum.cart  " + 
					"  where ct_me_id = ? and  ct_us_id =?";
			
			PreparedStatement stmt=con.prepareStatement(sql);
			
			stmt.setInt(2, (int) userId);
			stmt.setInt(1, (int) menuItemId);
			
			stmt.executeUpdate();
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	

}
