package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoSqlImpl implements MenuItemDao {

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		
		Connection con = ConnectionHandler.getConnection();
		
		ArrayList<MenuItem> list = new ArrayList<MenuItem>();
		
		try {
			
			
			
			PreparedStatement stmt=con.prepareStatement("select * from truyum.menu_item");
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				long id = (long) rs.getInt(1);
				
				String name = rs.getString(2);
				
				float price = rs.getFloat(3);
				
				String activ = rs.getString(4);
				
				boolean active = activ.equalsIgnoreCase("yes")? true :false;
				
				Date dat= rs.getDate(5);
				
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				
				String modDate = format.format(dat);
				
				Date fdate=null;
				try {
					fdate = format.parse(modDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String category = rs.getString(6);
				
				Boolean delivery = rs.getString(7).equalsIgnoreCase("yes") ? true : false;
				
				MenuItem mi = new MenuItem(id,name,price,active,fdate,category,delivery);
				
				list.add(mi);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		return list;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		

		Connection con = ConnectionHandler.getConnection();
		
		ArrayList<MenuItem> customerList = new ArrayList<MenuItem>();
		
		try {
			
			
			
			PreparedStatement stmt=con.prepareStatement("select * from menu_item " + 
					"where me_date_of_launch <= now() and me_active like \'yes\';");
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				long id = (long) rs.getInt(1);
				
				String name = rs.getString(2);
				
				float price = rs.getFloat(3);
				
				String activ = rs.getString(4);
				
				boolean active = activ.equalsIgnoreCase("yes")? true :false;
				
				Date dat= rs.getDate(5);
				
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				
				String modDate = format.format(dat);
				
				Date fdate=null;
				try {
					fdate = format.parse(modDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String category = rs.getString(6);
				
				Boolean delivery = rs.getString(7).equalsIgnoreCase("yes") ? true : false;
				
				MenuItem mi = new MenuItem(id,name,price,active,fdate,category,delivery);
				
				customerList.add(mi);
				
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return customerList;
	}
		


	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		
		Connection con = ConnectionHandler.getConnection();
		
		try {
			
			String active = menuItem.isActive() == true ? "yes" : "no" ;
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			String del = menuItem.isFreeDelivery() == true ? "yes" : "no" ;
			
			String date = format.format(menuItem.getDateOfLaunch());
			
			java.sql.Date moddate=null;
			try {
				moddate = java.sql.Date.valueOf(date);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			PreparedStatement stmt=con.prepareStatement("update menu_item set me_name=? ,me_price=?,"
					+ " me_active=?,me_date_of_launch=?,  me_category=? ,me_free_delivery =? where me_id =?");
			
			stmt.setString(1,menuItem.getName());
			stmt.setFloat(2,menuItem.getPrice());
			stmt.setString(3,active);
			stmt.setDate(4,(java.sql.Date) moddate);
			stmt.setString(5,menuItem.getCategory());
			stmt.setString(6,del);
			stmt.setInt(7, menuItem.getId().intValue());
			stmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		Connection con = ConnectionHandler.getConnection();
		
		MenuItem mi= null;
		
		try {
			
			PreparedStatement stmt=con.prepareStatement("select * from truyum.menu_item where me_id="+menuItemId);
			
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				
				long id = (long) rs.getInt(1);
				
				String name = rs.getString(2);
				
				float price = rs.getFloat(3);
				
				String activ = rs.getString(4);
				
				boolean active = activ.equalsIgnoreCase("yes")? true :false;
				
				Date dat= rs.getDate(5);
				
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				
				String modDate = format.format(dat);
				
				Date fdate=null;
				try {
					fdate = format.parse(modDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String category = rs.getString(6);
				
				Boolean delivery = rs.getString(7).equalsIgnoreCase("yes") ? true : false;
				
				mi = new MenuItem(id,name,price,active,fdate,category,delivery);
				
							
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mi;

	}

}
