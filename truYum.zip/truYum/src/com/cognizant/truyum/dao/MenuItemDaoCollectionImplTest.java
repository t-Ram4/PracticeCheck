package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.com.util.DateUtil;

public class MenuItemDaoCollectionImplTest {

public static void main(String[] args) throws ParseException {
    
       testGetMenuItemListAdmin();
        
       testGetMenuItemListCustomer();
        
       testModifyMenuItem();
       
       testGetMenuItemListAdmin();
        
}

    public static void testGetMenuItemListAdmin() throws ParseException {
    	
    	System.out.println(" Menu itemes of admin");
        
        MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
        
        List<MenuItem> menuItemList= menuItemDao.getMenuItemListAdmin(); 
        
        for(MenuItem menuItem : menuItemList) {
            
            System.out.println(menuItem.toString());
            
        }
    }
        
    public static void testGetMenuItemListCustomer() throws ParseException {
    	
        System.out.println(" Menu itemes of customer");
        
        MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
        
        for (MenuItem menuItem : menuItemDao.getMenuItemListCustomer()) {
            
            System.out.println(menuItem.toString());
        }
    }
        
    public static void testModifyMenuItem() {
        
        try {
        MenuItem FrenchFries = new MenuItem (4L,"French fries Mod", 157.00f, false, DateUtil.convertToDate("02/08/2017"), "Starters", true);
        
        MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
        
        menuItemDao.modifyMenuItem(FrenchFries);
        
        System.out.println(" Modified items");
        
        System.out.println(menuItemDao.getMenuItem(4L));
    }
        catch (ParseException e) {
            
            e.printStackTrace();
        }
    }
    
    
}
        
        
    
    
    


