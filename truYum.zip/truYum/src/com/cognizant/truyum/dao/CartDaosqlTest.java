package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Iterator;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaosqlTest {

	public static void main(String[] args) {
		addToCartItem();
		getallCartitem();
		removeitem();
		
	}
	
	static void addToCartItem() {
		
		CartDao cartDao = new CartDaoSqlImpl();
		
		cartDao.addCartItem(101,2);
		
	}
	
	static void getallCartitem() {
		
		CartDao cartDao = new CartDaoSqlImpl();
		
		ArrayList<MenuItem> list = null;
		
		try {
			
			if(cartDao.getAllCartItems(101).size()==0) {
				throw new CartEmptyException();
			}
			 list = (ArrayList<MenuItem>) cartDao.getAllCartItems(101);
			 
			 Iterator<MenuItem> itr = list.iterator();
			 
			 while(itr.hasNext()) {
				 
				 System.out.println(itr.next().toString());
			 }
			 
			 
		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	static void removeitem() {
		
		CartDao cartDao = new CartDaoSqlImpl();
		
		cartDao.removeCartItem(101, 2);
	}
	
	

}
