package com.cognizant.truyum.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.dao.MenuItemDaoSqlImpl;
import com.cognizant.truyum.model.MenuItem;

/**
 * Servlet implementation class ShowEditMenuItemServlet
 */
@WebServlet("/ShowEditMenuItem")
public class ShowEditMenuItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowEditMenuItemServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		MenuItemDao menuItemDao = null ;
		
		menuItemDao = new MenuItemDaoSqlImpl();
		
		
	Long id = 	Long.parseLong(request.getParameter("menuItemId"));
		
		MenuItem menuItem = menuItemDao.getMenuItem(id);
		
		List<String> fList = new ArrayList<String>();
		
		fList.add("Main Course");
		
		fList.add("Starters");
		
		fList.add("Desserts");
		
		fList.add("Drinks");
		
		String cate = menuItem.getCategory();
		
		fList.remove(cate);
		fList.add(0, cate);
		
		
		request.setAttribute("ftype", fList);
		
		request.setAttribute("menuitem", menuItem);
		
		
		
		RequestDispatcher rq = request.getRequestDispatcher("edit-menu-item.jsp");
		
		rq.forward(request, response);
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
