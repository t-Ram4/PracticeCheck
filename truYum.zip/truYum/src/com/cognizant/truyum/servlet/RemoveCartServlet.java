package com.cognizant.truyum.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartDaoCollectonImpl;
import com.cognizant.truyum.dao.CartDaoSqlImpl;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

/**
 * Servlet implementation class RemoveCartServlet
 */
@WebServlet("/RemoveCartItem")
public class RemoveCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Long menuItemId = Long.parseLong(request.getParameter("menuItemId"));
		
		CartDao cartDao = new CartDaoSqlImpl();
		
		Long userId = 101L;
		
		cartDao.removeCartItem(userId, menuItemId);
		
		request.setAttribute("removeCartItemStatus", true);
		
		try {
			if(cartDao.getAllCartItems(userId) != null) {
				
				List<MenuItem> list = cartDao.getAllCartItems(userId);
				
				request.setAttribute("removeList", list);
				
				RequestDispatcher rq = request.getRequestDispatcher("ShowCartServlet");
				
				rq.forward(request, response);
			}
		} catch (CartEmptyException e) {
			
			RequestDispatcher rq = request.getRequestDispatcher("cart-empty.jsp");
			
			rq.forward(request, response);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
