package com.cognizant.truyum.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.dao.MenuItemDaoSqlImpl;
import com.cognizant.truyum.model.MenuItem;

/**
 * Servlet implementation class EditMenuItemServlet
 */
@WebServlet("/EditMenuItemServlet")
public class EditMenuItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditMenuItemServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			Long id = Long.parseLong(request.getParameter("menuItemId"));
		
			String name = request.getParameter("fdname");
			
			float price = Float.parseFloat(request.getParameter("fprice"));
			
			boolean active = false;
			
			if(request.getParameter("factive").equalsIgnoreCase("yes"))
			{
				active = true;
			}
			
			else active = false;
			
		
			
			String date = request.getParameter("fdate");
			
			String category = request.getParameter("fcate");
			
			boolean delivery = false;
			
			if(request.getParameter("fdel")!=null && request.getParameter("fdel").equalsIgnoreCase("yes"))
			{
				delivery = true;
			}
			
			
			
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			Date fdate =null;
			try {
				 fdate = formatter.parse(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			MenuItem menuitem = new MenuItem(id,name,price,active,fdate,category,delivery);
			
			MenuItemDao menuItemDao = null;
			try {
				 menuItemDao = new  MenuItemDaoSqlImpl();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
				menuItemDao.modifyMenuItem(menuitem);
				
				RequestDispatcher rq = request.getRequestDispatcher("edit-menu-item-status.jsp");
				
				rq.forward(request, response);
		
	}

}
