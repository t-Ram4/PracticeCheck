package com.cognizant.com.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	static public Date convertToDate(String date) throws ParseException {
		
		SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
		
		Date cdate = formater.parse(date);
		
		return cdate;
		
	}

}
