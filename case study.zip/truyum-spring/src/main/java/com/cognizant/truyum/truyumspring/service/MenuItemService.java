package com.cognizant.truyum.truyumspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.truyum.truyumspring.model.MenuItem;
import com.cognizant.truyum.truyumspring.repository.MenuItemRepository;

@Service
public class MenuItemService {

	@Autowired
	private MenuItemRepository menuItemRepository;
	
	@Transactional
	public List<MenuItem> getMenuItemListAdmin()
	{
		return menuItemRepository.findAll();
	}
	
	@Transactional
	public List<MenuItem> getMenuItemListCustomer()
	{
		return menuItemRepository.findSelectedItems();
	}
	
	@Transactional
	public MenuItem getMenuItem(long menuItemId) 
	{
		return menuItemRepository.getOne(Long.toString(menuItemId));
	}
	
	@Transactional
	public void modifyMenuItem(MenuItem menuItem)
	{
		menuItemRepository.save(menuItem);
	}
}